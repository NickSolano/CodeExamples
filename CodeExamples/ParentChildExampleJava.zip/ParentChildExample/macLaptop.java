abstract public class macLaptop extends Laptop

{

    public macLaptop(String manufacturer, double price, double weight){

        super(manufacturer, price, weight);

    }


}
