/**
 * Created by Blackcitadelz on 3/14/2016.
 */
abstract public class windowLaptop extends Laptop

{

    public windowLaptop(String manufacturer, double price, double weight){

        super(manufacturer, price, weight);

    }


}
